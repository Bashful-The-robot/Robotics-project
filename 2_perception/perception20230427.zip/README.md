# BASHFUL_WS
Workspace developed in ROS for the project course in robotics and autonomous systems
